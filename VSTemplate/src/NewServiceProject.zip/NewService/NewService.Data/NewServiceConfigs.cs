﻿using System;

namespace NewService.Data
{
    public static class NewServiceConfigs
    {
        public static string AppTitle = "This is NewService Project";
    }
}
