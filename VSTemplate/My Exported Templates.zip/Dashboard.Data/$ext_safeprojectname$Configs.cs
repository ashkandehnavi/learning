﻿using System;

namespace $ext_safeprojectname$.Data
{
    public static class $ext_safeprojectname$Configs
    {
        public static string AppTitle = "This is $ext_safeprojectname$ Project";
    }
}
